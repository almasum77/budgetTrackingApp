This folder will be used for testing docs and screenshoots
